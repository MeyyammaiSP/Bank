package com.me393625.bank1.Repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.me393625.bank1.model.Account;
import com.me393625.bank1.model.Customer;


@Repository
public interface BankRepository extends MongoRepository<Customer, String>
{
	Customer findOneByfirstName(String firstName);

    List<Customer> findAllByfirstName(String firstName);

    Customer findOneBylastName(String lastname);
    
    List<Customer> findAllBylastName(String lastname);

    Customer findOneByphoneNumber(long phoneNumber);

    List<Customer> findAllByphoneNumber(long phoneNumber);

    Customer findOneByuserId(String userId);
}
