package com.me393625.bank1.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;




@Document
public class Customer {
	 @Id
	 private String customerid;
	    private String userId;
	    private String firstName;
	    private String lastName;
	    private long phoneNumber;
	    private Address address;
	    private Account accountDetails;
	    
	   
	    
	    public Customer(String customerid, String userId, String firstName, String lastName, long phoneNumber,
	            Address address, Account accountDetails) {
	        this.customerid = customerid;
	        this.userId = userId;
	        this.firstName = firstName;
	        this.lastName = lastName;
	        this.phoneNumber = phoneNumber;
	        this.address = address;
	        this.accountDetails = accountDetails;
	    }
	    public String getUserId() {
	        return userId;
	    }
	    public void setUserId(String userId) {
	        this.userId = userId;
	    }
	    public String getCustomerid() {
	        return customerid;
	    }
	    public void setCustomerid(String customerid) {
	        this.customerid = customerid;
	    }
	    public Address getAddress() {
	        return address;
	    }
	    public void setAddress(Address address) {
	        this.address = address;
	    }
	    public Account getAccountDetails() {
	        return accountDetails;
	    }
	    public void setAccountDetails(Account accountDetails) {
	        this.accountDetails = accountDetails;
	    }
	    public long getPhoneNumber() {
	        return phoneNumber;
	    }
	    public void setPhoneNumber(long phoneNumber) {
	        this.phoneNumber = phoneNumber;
	    }
	    public String getFirstName() {
	        return firstName;
	    }
	    public void setFirstName(String firstName) {
	        this.firstName = firstName;
	    }
	    public String getLastName() {
	        return lastName;
	    }
	    public void setLastName(String lastName) {
	        this.lastName = lastName;
	    }  
	    
	}
