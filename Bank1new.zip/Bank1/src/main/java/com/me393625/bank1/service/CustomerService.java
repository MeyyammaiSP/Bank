package com.me393625.bank1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.me393625.bank1.Repository.BankRepository;
import com.me393625.bank1.model.Address;
import com.me393625.bank1.model.Customer;




@Service
public class CustomerService implements ServiceInterface{
	
	@Autowired
    BankRepository repo;
	public Customer create_account(Customer customer)throws Exception
    {
         String chk = customer.getFirstName()+
                         customer.getLastName()+
                         customer.getPhoneNumber();
         //check if the customer list is empty
         if(repo.count()!=0)
         {
             //check if the customer already exists
             List<Customer> customerList = repo.findAllByfirstName(customer.getFirstName());
             for (Customer c : customerList) {
                 String check = c.getFirstName()+c.getLastName()+c.getPhoneNumber();
                 if(check.equalsIgnoreCase(chk))
                     {
                         
                         //throw exception for the existing customer
                         throw new Exception("The customer already exists");
                     }
             }
         }
        repo.insert(customer);
        //creating account number
        customer.getAccountDetails().setAccountNumber(customer.getAccountDetails().getAccountType()+customer.getCustomerid());
        //creating user id
        customer.setUserId(customer.getFirstName()+customer.getLastName().charAt(0)+customer.getPhoneNumber()%100);
        repo.save(customer);
        return customer;
    }

    public List<Customer> findAllCustomers() throws Exception
    {
        List<Customer> c = repo.findAll();
        if( c.size()==0)
         {throw new Exception("No records exist");}
     else 
         return c;

    }

    public void deleteAllCustomers(){
        
         repo.deleteAll();
    }
 

 public Customer updateFirstName(String firstName, String userId) {
     // customer will contain a changed parameter and userId will fetch the customer to be updated
     Customer c = repo.findOneByuserId(userId);
     c.setFirstName(firstName);
     repo.save(c);
     
     return repo.findById(c.getCustomerid()).get();
 }

 public Customer updateLastName(String lastName, String userId) {
     Customer c = repo.findOneByuserId(userId);
     c.setLastName(lastName);
     repo.save(c);

     return repo.findById(c.getCustomerid()).get();
 }

 public Customer updatephoneNumber(Long phoneNumber, String userId) {

     Customer c = repo.findOneByuserId(userId);
     c.setPhoneNumber(phoneNumber);
     repo.save(c);

     return repo.findById(c.getCustomerid()).get();

 }

 public Customer updateAddress(Address address, String userId) {

     Customer c = repo.findOneByuserId(userId);
     c.setAddress(address);
     repo.save(c);
     return repo.findById(c.getCustomerid()).get();
 }

 public Customer findByLastName(String field) {

     return repo.findOneBylastName(field);
 
 }

 public void deleteById(String userId) {
     
     repo.deleteById(repo.findOneByuserId(userId).getCustomerid());
 }

 public Customer findByFirstName(String field) {
     return repo.findOneByfirstName(field);
 }

 public Customer findByphoneNumber(long field) {
     return repo.findOneByphoneNumber(field);
 }
 public List<Customer> findAllByFirstName(String field) {
     return repo.findAllByfirstName(field);
 }

public List<Customer> findAllByLastName(String field) {

     return repo.findAllBylastName(field);
 
 }

 public List<Customer> findAllByphoneNumber(long field) {
     return repo.findAllByphoneNumber(field);
 }

 public ResponseEntity<String> fundTransfer(List<Customer> customer, Double amount) throws Exception {
     
     Customer debitor = repo.findOneByuserId(customer.get(0).getUserId());

     //if debitor equals null throw user not found exception
     if(debitor==null){ 
         throw new Exception("No such user exists");
     } //throw error
     
     Customer reciever = repo.findOneByuserId(customer.get(1).getUserId());
     
     if(reciever==null){
         throw new Exception("No such beneficiary exists");
     } // throw error
     //if reciever equals null throw no such beneficiary exists
     
     Double debitor_balance = debitor.getAccountDetails().getAccountBalance();
     if(amount<=debitor_balance){
         //fund transfer possible
         debitor.getAccountDetails().setAccountBalance(debitor_balance-amount);
         reciever.getAccountDetails().setAccountBalance(reciever.getAccountDetails().getAccountBalance()+amount);
         repo.save(reciever);
         repo.save(debitor);

     }
     else//throw error fund transfer failed insufficient balance
         throw new Exception("Fund transfer failed! Insufficient balance.");


     return new ResponseEntity<>("Fund transfer successful", HttpStatus.OK);
 }








}
