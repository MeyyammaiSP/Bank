package com.me393625.bank1.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.me393625.bank1.model.Address;
import com.me393625.bank1.model.Customer;


public interface ServiceInterface {
	 public Customer create_account(Customer customer) throws Exception;
	    
	    public void deleteAllCustomers();
	    public void deleteById(String userId);

	    public Customer updateFirstName(String firstName, String userId);
	    public Customer updateLastName(String lastName, String userId);
	    public Customer updatephoneNumber(Long phoneNumber, String userId);
	    public Customer updateAddress(Address address, String userId);

	    public List<Customer> findAllCustomers() throws Exception;
	    public Customer findByLastName(String field);
	    public Customer findByFirstName(String field);
	    public Customer findByphoneNumber(long field);
	    public List<Customer> findAllByLastName(String field);
	    public List<Customer> findAllByFirstName(String field);
	    public List<Customer> findAllByphoneNumber(long field);
	    public ResponseEntity<String> fundTransfer(List<Customer> customer, Double amount) throws Exception;


}
