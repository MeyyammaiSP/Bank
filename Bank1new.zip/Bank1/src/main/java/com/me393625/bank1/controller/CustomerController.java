package com.me393625.bank1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.me393625.bank1.model.Address;
import com.me393625.bank1.model.Customer;
import com.me393625.bank1.service.CustomerService;

@RestController
public class CustomerController {
	@Autowired
    CustomerService service;

    @PostMapping("/createaccount") /////////////////
    public Customer createnewaccount(@RequestBody Customer customer) throws Exception
    {

        return service.create_account(customer);
    }
    /*

    ************
    GET REQUESTS
    ************

     */


    @GetMapping("/") ////////////////////
    public String startPage()
    {
        return "Welcome to project";
    }

    @GetMapping("/customers") ///////////////////
    public List<Customer> getAllCustomers() throws Exception
    {
        return service.findAllCustomers();
    }
    /*

    *****************
    FIND ALL BY FIELD
    *****************
    
    */
    @GetMapping("/customer/findAll/lastName/")
    public List<Customer> findAllByLastName(@RequestParam(name = "lastName") String field){
        return service.findAllByLastName(field);
    }
    @GetMapping("/customer/findAll/firstName/")
    public List<Customer> findAllByFirstName(@RequestParam(name = "firstName") String field){
        return service.findAllByFirstName(field);
    }
    @GetMapping("/customer/findAll/phoneNumber/")
    public List<Customer> findAllByphoneNumber(@RequestParam(name = "phoneNumber") long field){
        return service.findAllByphoneNumber(field);
    }

    /*

    *****************
    FIND ONE BY FIELD
    *****************
    
    */

    @GetMapping("/customer/find/firstName")
    public Customer findByFirsttName(@RequestParam(name = "firstName") String field){
        return service.findByFirstName(field);
    }
    @GetMapping("/customer/find/phoneNumber")
    public Customer findByPhoneNumber(@RequestParam(name = "phoneNumber") long field){
        return service.findByphoneNumber(field);
    }
    @GetMapping("/customer/find/lastName")
    public Customer findByLastName(@RequestParam(name = "lastName") String field){
        return service.findByLastName(field);
    }

    /*
    
    ***************
    UPDATE REQUESTS
    ***************
    
    */

    @PutMapping("/customer/update/firstName/{userId}/")
    public Customer updateFirstName(@RequestParam(name = "firstName") String firstName, @PathVariable String userId){
        return service.updateFirstName(firstName, userId);
    }

    @PutMapping("/customer/update/lastName/{userId}/")
    public Customer updateLastName(@RequestParam(name = "lastName")  String lastName, @PathVariable String userId){
        return service.updateLastName(lastName, userId);
    }

    @PutMapping("/customer/update/phoneNumber/{userId}/")
    public Customer updatephoneNumber(@RequestParam(name = "phoneNumber") Long lastName, @PathVariable String userId){
        return service.updatephoneNumber(lastName, userId);
    }
    @PutMapping("/customer/update/address/{userId}/")
    public Customer updateAddress(@RequestBody Address address, @PathVariable String userId){
        return service.updateAddress(address, userId);
    }
    

    /*
    ***************
    DELETE REQUESTS
    ***************
    */
    @DeleteMapping("/deleteCustomer/")
    public void deleteById(@RequestParam(name = "userId") String userId)
    {
        service.deleteById(userId);
    }

    @DeleteMapping("/deleteCustomers")
    public void deleteAllCustomers()
    {
        service.deleteAllCustomers();
    }

    /*
    *************
    FUND TRANSFER
    *************
    */
    @PutMapping("/customer/fundtransfer/")
    public ResponseEntity<String> fundTransfer(@RequestBody List<Customer> customer, @RequestParam(name = "amount") Double amount) throws Exception
    {
        
        return service.fundTransfer(customer, amount);
    }
}

/*

{
    "firstName":"Meyyammai",
    "lastName":"SP",
    "phoneNumber":8145678945,
    "address":{
        "houseNumber":12,
        "streetName":"Veerainkanmai Street",
        "city":"KKdi",
        "pin":630001
    },
    "accountDetails":{
        "accountType":"savings",
        "accountBalance":1000.00
    }
}

*/

